$(document).ready( function () {
  $('table').heavyTable({
        xPosition: 1,
        yPosition: 1
      }); 
});